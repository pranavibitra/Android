package com.example.hp.listviewmodel;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    ListView list;
    List<Model> items;
    String names[]={"Sky","Nature","waterfall","flower"};
    String discrp[]={"Blue","Green","white","yellow"};
    int image[]={R.drawable.sky,R.drawable.nature,R.drawable.waterfall,R.drawable.flower};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        items = new ArrayList<Model>();
        for (int i = 0; i < names.length; i++)
        {
            Model ite=new Model(image[i],names[i],discrp[i]);
            items.add(ite);
        }
        list = (ListView) findViewById(R.id.lvb);
        Adapter adp=new Adapter(this,items);
        list.setAdapter(adp);

    }
}