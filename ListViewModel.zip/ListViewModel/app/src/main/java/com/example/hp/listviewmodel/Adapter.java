package com.example.hp.listviewmodel;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class Adapter extends BaseAdapter {
    List<Model> items;
    Context context;

    public Adapter(Context context,List<Model> obj)
    {
        this.context=context;
        this.items=obj;
    }
    private class ViewHolder{

        ImageView img11;
        TextView tv2,tv3;


    }
    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int position) {
        return items.get(position);
    }

    @Override
    public long getItemId(int position) {
        return items.indexOf(getItem(position));

    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder = null;
        LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
        if (convertView == null)
        {
            convertView = layoutInflater.inflate(R.layout.activity_listview, null);
        viewHolder = new ViewHolder();
        viewHolder.img11 = (ImageView) convertView.findViewById(R.id.img);
        viewHolder.tv2 = (TextView) convertView.findViewById(R.id.tvb);
        viewHolder.tv3 = (TextView) convertView.findViewById(R.id.tv1);

        convertView.setTag(viewHolder);

    }
    else
        {
            viewHolder=(ViewHolder)convertView.getTag();

        }
    Model model=(Model)getItem(position);
        viewHolder.tv2.setText(model.getTitle());
        viewHolder.tv3.setText(model.getDesc());
        viewHolder.img11.setImageResource(model.getImageid());

        return convertView;
    }

}