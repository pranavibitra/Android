package com.example.hp.listviewwithbaseadapter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.BaseAdapter;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {
 ListView list;
 String names[]={"Sky","Nature","waterfall","flower"};
 int image[]={R.drawable.sky,R.drawable.nature,R.drawable.waterfall,R.drawable.flower};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        list=(ListView)findViewById(R.id.lvb);
        Adapter adp=new Adapter(getApplicationContext(),names,image);
        list.setAdapter(adp);

    }
}
