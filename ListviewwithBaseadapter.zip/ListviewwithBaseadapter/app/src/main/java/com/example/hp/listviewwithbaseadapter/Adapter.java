package com.example.hp.listviewwithbaseadapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class Adapter extends BaseAdapter {
    ImageView imageview;
    TextView textview;
    Context context;
    String names[];
    int image[];
    LayoutInflater inflater;
    public Adapter(Context context,String[] names,int[] image)
    {
        this.context=context;
        this.names=names;
        this.image=image;
        inflater=(LayoutInflater.from(context));
    }

    @Override
    public int getCount() {

        return names.length;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView=inflater.inflate(R.layout.activity_listview,null);
        imageview=(ImageView)convertView.findViewById(R.id.img);
        textview=(TextView)convertView.findViewById(R.id.tvb);
        textview.setText(names[position]);
        imageview.setImageResource(image[position]);
        return convertView;
    }
}
