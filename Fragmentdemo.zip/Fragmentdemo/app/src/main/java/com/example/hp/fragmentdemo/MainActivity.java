package com.example.hp.fragmentdemo;

import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button firstfragment, secondfragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        firstfragment = (Button) findViewById(R.id.firstfrag);
        secondfragment = (Button) findViewById(R.id.secondfrag);
        firstfragment.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View v) {
                loadFragment(new FirstFragment());

            }
        });
        secondfragment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadFragment(new SecondFragment());
            }
        });
    }
        private void loadFragment(Fragment fragment)
        {
            FragmentManager fm=getFragmentManager();
            FragmentTransaction ft=fm.beginTransaction();
            ft.replace(R.id.framelay,fragment);
            ft.commit();
        }

}
