package com.example.hp.sqlitedemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
EditText name,pwd,curname,newname,deletename;
Sqladapter helper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        name=(EditText)findViewById(R.id.etu);
        pwd=(EditText)findViewById(R.id.etp);
        curname=(EditText)findViewById(R.id.etcu);
        newname=(EditText)findViewById(R.id.etnn);
        deletename=(EditText)findViewById(R.id.etdn);
        helper=new Sqladapter(this);


    }
    public void addUser(View view)
    {
        String t1 = name.getText().toString();
        String t2 = pwd.getText().toString();
        if(t1.isEmpty() || t2.isEmpty())
        {
            Message.message(getApplicationContext(),"Enter Both Name and Password");
        }
        else
        {
            long id = helper.insertData(t1,t2);
            if(id<=0)
            {
                Message.message(getApplicationContext(),"Insertion Unsuccessful");
                name.setText("");
                pwd.setText("");
            } else
            {
                Message.message(getApplicationContext(),"Insertion Successful");
                name.setText("");
                pwd.setText("");
            }
        }
    }

    public void viewdata(View view)
    {
        String data = helper.getData();
        Message.message(this,data);
    }

    public void update( View view)
    {
        String u1 = curname.getText().toString();
        String u2 = newname.getText().toString();
        if(u1.isEmpty() || u2.isEmpty())
        {
            Message.message(getApplicationContext(),"Enter Data");
         //   Toast.makeText(getApplicationContext(),"hai" ,Toast.LENGTH_LONG).show();
        }
        else
        {
            int a= helper.updateName( u1, u2);
            if(a<=0)
            {
                Message.message(getApplicationContext(),"Unsuccessful");
                curname.setText("");
                newname.setText("");
            } else {
                Message.message(getApplicationContext(),"Updated");
                curname.setText("");
                newname.setText("");
            }
        }

    }
    public void delete( View view)
    {
        String uname = deletename.getText().toString();
        if(uname.isEmpty())
        {
            Message.message(getApplicationContext(),"Enter Data");
        }
        else{
            int a= helper.delete(uname);
            if(a<=0)
            {
                Message.message(getApplicationContext(),"Unsuccessful");
                deletename.setText("");
            }
            else
            {
                Message.message(this, "DELETED");
                deletename.setText("");
            }
        }
    }
}